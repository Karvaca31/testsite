<?php

error_reporting(0);
require("heart.php");

$zwous = $_SESSION["zwous"];
$url = "https://dumpor.com/v/$zwous";
$ig = str_get_html(file_get_contents($url));


$zewo = $ig->find("div[class='user__img']", 0)->style;
$pp = substr($zewo, 27, -4);

$zew1 = $ig->find("div[class='user__info-desc']", 0);
$bio = substr($zew1, 0, -13);

$gonderi = $ig->find("a[class='btn btn-dark text-white m-1']", 0)->plaintext;
$takipci = $ig->find("a[class='btn btn-light m-1']", 0)->plaintext;
$takip = $ig->find("a[class='btn btn-light m-1']", 1)->plaintext;

$fff4 = $ig->find("img[class='content__img']", 0)->src;



$f_count = $ig->find("a[class='btn btn-light m-1']", 1);

$follower_count = substr($f_count, 0, -13);
$name = $ig->find("div[class='user__title']", 0)->childNodes(0)->plaintext;

$zew = $ig->find("img[class='content__img']", 0)->alt;



$tf = $ig->find("img[class='content__img']", 0)->src;


    /////////////////////////////////////////////////////////////
    ////////////////ZWO/////////////////////////////////////////
    ////////////////////////////////////////////////////////////
